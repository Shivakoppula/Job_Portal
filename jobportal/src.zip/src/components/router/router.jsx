import { createBrowserRouter } from "react-router-dom";
import Register from "../register/Register";
import Login from "../login/Login";
import SpinLoaders from "../loaders/SpinLoaders";
import Home from "../Home/Home";

let router = createBrowserRouter([
    {
        path:"/",
        element:<Register></Register>
    },
    {
        path:"/login",
        element:<Login></Login>   
    }
    ,{
        path:"/home",
        element:<Home></Home>
    }
    
])




export default router;