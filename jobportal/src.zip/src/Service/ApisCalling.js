import axiosInstance from "../instance/axiosInstance";

let ApisCalling={
    register : async(payload)=>{
        console.log("Sending payload:", payload);
        let data=await axiosInstance.post("/api/users/register",payload);
        return data;
    },
    verifyOtp : async(registrationId, otp)=>{
        console.log("Verifying OTP for registration ID:", registrationId);
        let data=await axiosInstance.post("/api/users/verify-otp", {userId: registrationId, otp});
        return data;
    },
    loginUser:async(payload)=>{
        let data=await axiosInstance.post("/api/users/login",payload);
        return data;
    }
}
export default ApisCalling;